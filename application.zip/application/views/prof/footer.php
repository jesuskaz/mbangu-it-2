<footer class="main-footer">
        <div style="text-align:center">
          <a href="templateshub.net" >MbanguPay</a></a>
        </div>
</footer>
  <!-- General JS Scripts -->
  <script src="<?php echo base_url().'assets/js/app.min.js'; ?>"></script>
  <!-- JS Libraies s-->
  <script src="<?php echo base_url().'assets/bundles/owlcarousel2/dist/owl.carousel.min.js'; ?>"></script>
  <!-- Page Specific JS File -->
  <script src="<?php echo base_url().'assets/js/page/owl-carousel.js'; ?>"></script>
  <!-- Template JS File -->
  <script src="<?php echo base_url().'assets/js/scripts.js'; ?>"></script>
  <!-- Custom JS File -->
  <script src="<?php echo base_url().'assets/js/custom.js'; ?>"></script>

  <script src="<?php echo base_url().'assets/bundles/fullcalendar/fullcalendar.min.js'; ?>"></script>
  <!-- Page Specific JS File -->
  <script src="<?php echo base_url().'assets/js/page/calendar.js'; ?>"></script>

  <!-- An other data -->

   <!-- General JS Scripts -->
   <script src="assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <!-- Page Specific JS File -->
  <script src="<?php echo base_url().'assets/js/page/index.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/datatables.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/export-tables/dataTables.buttons.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/export-tables/buttons.flash.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/export-tables/jszip.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/export-tables/pdfmake.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/apexcharts/apexcharts.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/export-tables/vfs_fonts.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/bundles/datatables/export-tables/buttons.print.min.js'; ?>"></script>
  <script src="<?php echo base_url().'assets/js/page/datatables.js'; ?>"></script>
</footer>