<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Mbangu</title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/app.min.css'; ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/bundles/owlcarousel2/dist/assets/owl.carousel.min.css'; ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/bundles/owlcarousel2/dist/assets/owl.theme.default.min.css'; ?>">
  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'; ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/components.css'; ?>">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/custom.css';?>">
  <link rel='shortcut icon' type='image/x-icon' href="<?php echo base_url().'assets/img/favicon.ico'; ?>"/>

  <link rel="stylesheet" href="<?php echo base_url().'assets/bundles/fullcalendar/fullcalendar.min.css'; ?>" />
  <link rel="stylesheet" href="<?php echo base_url().'assets/bundles/jquery-selectric/selectric.css'; ?>">

  <link rel='shortcut icon' type='image/x-icon' href="<?php echo base_url().'assets/img/favicon.ico';?>"/>
  <!-- data geting with ajax -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
