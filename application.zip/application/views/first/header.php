<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mbangupay, permet d’apporter des solutions idoines. Sécurité, rapidité, facilité, Mbangupay est une solution informatique qui répondra correctement aux besoins des étudiants et élèves." />
<meta name="keywords" content="mbangupay, paiement, frais" />
<meta name="author" content="mbangupay" />

<link rel='shortcut icon' type='image/x-icon' href="<?php echo base_url() . 'assets/img/favicon.ico'; ?>" />
<link rel="stylesheet" href="<?= base_url('first/css/animate.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/icomoon.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/bootstrap.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/magnific-popup.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/owl.carousel.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/owl.theme.default.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/flexslider.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/pricing.css'); ?>">
<link rel="stylesheet" href="<?= base_url('first/css/style.css'); ?>">
<script src="<?= base_url('first/js/modernizr-2.6.2.min.js'); ?>"></script>

<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400" rel="stylesheet">