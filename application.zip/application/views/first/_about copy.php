<?php include('header.php'); ?>
<?php include('header2.php'); ?>
<div id="fh5co-about">
	<div class="container">
		<div class="col-md-6 animate-box">
			<span>A propo de Mbangu pay</span>
			<h2>Mbangu pay est une application mobile qui permet aux étudiants d’effectuer le paiement rapide </h2>
			<p>et sécurisé des frais académiques à partir de leur mobile à n'importe quelle heure et partout où </p>
			<p>ilsse trouvent. Il s’agit d’une solution à la mesure des défis auxquels font face les différents </p>
			<p>intervenants et une solution 24/7 et au départ de son compte en banque et autres tels que </p>
			<p>orange money , Airtel money, M-pesa , carte visa , MasterCard …avec un niveau de sécurité </p>
			<p>très élevé </p>
		</div>
		<div class="col-md-6">
			<img class="img-responsive" src="<?= base_url('first/images/img_bg_2.jpg'); ?>" alt="Free HTML5 Bootstrap Template">
		</div>
	</div>
</div>
<?php include('footer.php'); ?>