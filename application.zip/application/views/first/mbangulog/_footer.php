
<div class="row" style="padding-top: 60px; clear: both;">
	<div class="col-md-12 text-center">
	<p><small>&copy; All Rights Reserved. Designed by <a href="#">Mbangu pay</a></small></p></div>
		</div>
		</div>
	<!-- jQuery -->
	<script src="<?=base_url('foot/js/jquery.min.js'); ?>"></script>
	<!-- Bootstrap -->
	<script src="<?=base_url('foot/js/bootstrap.min.js'); ?>"></script>
	<!-- Placeholder -->
	<script src="<?=base_url('foot/js/jquery.placeholder.min.js'); ?>"></script>
	<!-- Waypoints -->
	<script src="<?=base_url('foot/js/jquery.waypoints.min.js'); ?>"></script>
	<!-- Main JS -->
	<script src="<?=base_url('foot/js/main.js'); ?>"></script>
	</body>
</html>

