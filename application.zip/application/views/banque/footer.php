<footer class="main-footer">
  <div class="footer-left"> <a href="#" class="text-warning">MbanguPay</a></a>
  </div>
</footer>
<script src="<?php echo base_url() . 'assets/js/app.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/owlcarousel2/dist/owl.carousel.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/page/owl-carousel.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/scripts.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/custom.js'; ?>"></script>

<script src="<?php echo base_url() . 'assets/js/page/indexUniv.js'; ?>"></script>


<script src="<?php echo base_url() . 'assets/bundles/fullcalendar/fullcalendar.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/page/calendar.js'; ?>"></script>

<link rel="stylesheet" href="<?= base_url('/') ?>assets/bundles/datatables/datatables.min.css">

<script src="<?php echo base_url() . 'assets/js/page/index.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/datatables.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/export-tables/dataTables.buttons.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/export-tables/buttons.flash.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/export-tables/jszip.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/export-tables/pdfmake.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/apexcharts/apexcharts.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/export-tables/vfs_fonts.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/bundles/datatables/export-tables/buttons.print.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/page/datatables.js'; ?>"></script>