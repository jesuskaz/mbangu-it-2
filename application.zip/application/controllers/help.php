            <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                  <div class="card-header">
                    <h4>Votre Promotion</h4>
                  </div>
                  <div class="card-body">
                    <!-- primary -->
                    <div class="pretty p-default">
                      <input type="checkbox" name="promotion[]" value="prepa"/> 
                      <div class="state p-primary">
                        <label>Preparatoire</label>
                      </div>
                    </div>
                    <div class="pretty p-default">
                      <input type="checkbox" name="promotion[]" value="g1"/>
                      <div class="state p-primary">
                        <label>G1</label>
                      </div>
                    </div>
                    <!-- success -->
                    <div class="pretty p-default">
                      <input type="checkbox" name="promotion[]" value="g2"/>
                      <div class="state p-success">
                        <label>G2</label>
                      </div>
                    </div>
                    <!-- info -->
                    <div class="pretty p-default">
                      <input type="checkbox" name="promotion[]" value="g3"/>
                      <div class="state p-info">
                        <label>G3</label>
                      </div>
                    </div>
                    <!-- warning -->
                    <div class="pretty p-default">
                      <input type="checkbox" name="promotion[]" value="l1"/>
                      <div class="state p-warning">
                        <label>L1</label>
                      </div>
                    </div>
                    <!-- danger -->
                    <div class="pretty p-default">
                      <input type="checkbox" name="promotion[]" value="l2"/>
                      <div class="state p-danger">
                        <label>L2</label>
                      </div>
                    </div>
                  </div>
                </div>
            </div>