<?php
    class Infos extends CI_Controller
    {
        public function getStudentById()
        {
            echo "Message Ok";
        }
    }
?>